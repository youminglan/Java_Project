import MessageTable from './ManageTable'

export default MessageTable
