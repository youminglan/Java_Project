import Log from './DispatchManage'

export default Log
