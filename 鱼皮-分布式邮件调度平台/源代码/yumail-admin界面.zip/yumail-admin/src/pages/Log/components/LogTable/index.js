import LogTable from './LogTable'

export default LogTable
