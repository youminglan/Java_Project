import Log from './Log'

export default Log
