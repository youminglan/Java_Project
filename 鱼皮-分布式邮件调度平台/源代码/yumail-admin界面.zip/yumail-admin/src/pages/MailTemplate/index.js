import MailTemplate from './MailTemplate'

export default MailTemplate
