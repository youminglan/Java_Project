import BasicForm from './BasicForm';

export default BasicForm;
