import SendMail from './SendMail'

export default SendMail
